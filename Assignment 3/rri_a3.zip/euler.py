from pyspark import SparkConf, SparkContext
import sys, random
assert sys.version_info >= (3, 5) # make sure we have Python 3.5+
def samples_summed(samples):
    total_iterations=0
    random.seed()
    for i in samples:
        iterations=0
        sum=0.0
        while sum<1:
            sum+=random.uniform(0,1)
            iterations+=1
        total_iterations+=iterations
        
    return total_iterations 

def add(x,y):
    return x+y

def main(inputs):
    rdd=sc.range(inputs,numSlices=35).glom()
    rdd_total=rdd.map(samples_summed).reduce(add)
    expected_value=rdd_total/inputs
    print(expected_value)
if __name__ == '__main__':
    conf = SparkConf().setAppName('euler')
    sc = SparkContext(conf=conf)
    sc.setLogLevel('WARN')
    assert sc.version >= '3.0'  # make sure we have Spark 3.0+
    inputs = int(sys.argv[1])
    main(inputs)