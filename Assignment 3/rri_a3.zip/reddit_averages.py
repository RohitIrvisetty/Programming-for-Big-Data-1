from pyspark import SparkConf, SparkContext
import sys, json
assert sys.version_info >= (3, 5) # make sure we have Python 3.5+

def mapper_function(l):
    tokens=json.loads(l)
    return (tokens["subreddit"],(1,tokens["score"]))

def reducer_add(l1,l2):
    comment_count=l1[0]+l2[0]
    total_score=l1[1]+l2[1]
    return (comment_count,total_score)

def reducer_avg(l):
    reducer_key=l[0]
    reducer_count=l[1][0]
    reducer_score=l[1][1]
    reducer_value=reducer_score/reducer_count
    return (reducer_key,reducer_value)

def main(inputs, output):
    # main logic starts here
    text = sc.textFile(inputs)
    reddit_mapper=text.map(mapper_function)
    reddit_reducer=reddit_mapper.reduceByKey(reducer_add).map(reducer_avg)
    outdata=reddit_reducer.map(json.dumps)
    print(outdata.take(10))
    outdata.saveAsTextFile(output)


if __name__ == '__main__':
    conf = SparkConf().setAppName('reddit_averages')
    sc = SparkContext(conf=conf)
    sc.setLogLevel('WARN')
    assert sc.version >= '3.0'  # make sure we have Spark 3.0+
    inputs = sys.argv[1]
    output = sys.argv[2]
    main(inputs, output)