from pyspark import SparkConf, SparkContext
import sys, json
assert sys.version_info >= (3, 5) # make sure we have Python 3.5+

def mapper_function(subreddit):
    tokens=json.loads(subreddit)
    subreddit_key=tokens["subreddit"]
    subreddit_score=tokens["score"]
    subreddit_author=tokens["author"]
    return (subreddit_key,subreddit_score,subreddit_author)

def mapper_filter(subreddit):
    if 'e' in subreddit[0]:
        return True
    else:
        return False

def main(inputs, output):
    # main logic starts here
    text = sc.textFile(inputs)
    reddit_mapper=text.map(mapper_function).filter(mapper_filter)
    postive_output=reddit_mapper.filter(lambda x:x[1]>0).map(json.dumps)
    negative_output=reddit_mapper.filter(lambda x:x[1]<0).map(json.dumps)
    print(postive_output.take(10))
    print(negative_output.take(10))
    postive_output.saveAsTextFile(output+'/positive')
    negative_output.saveAsTextFile(output+'/negative')

if __name__ == '__main__':
    conf = SparkConf().setAppName('reddit_averages')
    sc = SparkContext(conf=conf)
    sc.setLogLevel('WARN')
    assert sc.version >= '3.0'  # make sure we have Spark 3.0+
    inputs = sys.argv[1]
    output = sys.argv[2]
    main(inputs, output)