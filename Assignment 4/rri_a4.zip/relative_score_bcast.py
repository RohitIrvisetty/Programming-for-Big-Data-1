from pyspark import SparkConf, SparkContext
import sys, json
assert sys.version_info >= (3, 5) # make sure we have Python 3.5+

def mapper_function(l):
    subreddit_key=l["subreddit"]
    subreddit_score=l["score"]
    return (subreddit_key,(1,subreddit_score))

def reducer_add(l1,l2):
    comment_count=l1[0]+l2[0]
    total_score=l1[1]+l2[1]
    return (comment_count,total_score)

def reducer_avg(l):
    reducer_key=l[0]
    reducer_count=l[1][0]
    reducer_score=l[1][1]
    reducer_value=reducer_score/reducer_count
    return (reducer_key,reducer_value)

def relative_score(l,broadcast_avg):
    key_score=(l["score"])/(broadcast_avg.value[l["subreddit"]])
    value_author=l["author"]
    return (key_score,value_author)

def main(inputs, output):
    # main logic starts here
    text=sc.textFile(inputs)
    json_text=text.map(json.loads).cache()
    reddit_mapper=json_text.map(mapper_function)
    reddit_reducer=reddit_mapper.reduceByKey(reducer_add).map(reducer_avg)
    reddit_reducer_filtered=reddit_reducer.filter(lambda x:x[1]>0)
    average_broadcast=sc.broadcast(dict(reddit_reducer_filtered.collect()))
    commentbysub=json_text.map(lambda x:relative_score(x,average_broadcast))
    final_result=commentbysub.sortBy(lambda x: -x[0])
    outdata=final_result.map(json.dumps)
    print(outdata.take(10))
    outdata.saveAsTextFile(output)

if __name__ == '__main__':
    conf = SparkConf().setAppName('reddit_averages')
    sc = SparkContext(conf=conf)
    sc.setLogLevel('WARN')
    assert sc.version >= '3.0'  # make sure we have Spark 3.0+
    inputs = sys.argv[1]
    output = sys.argv[2]
    main(inputs, output)