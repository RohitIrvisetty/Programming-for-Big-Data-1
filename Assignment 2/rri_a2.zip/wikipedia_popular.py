from pyspark import SparkConf, SparkContext
import sys

inputs = sys.argv[1]
output = sys.argv[2]

conf = SparkConf().setAppName('wikipedia_popular')
sc = SparkContext(conf=conf)
assert sys.version_info >= (3, 5)  # make sure we have Python 3.5+
assert sc.version >= '2.3'  # make sure we have Spark 2.3+
def words_once(line):
    tokens=line.split() 
    yield (tokens)

def max_value(x,y):
    if x[0]>=y[0]:
        return x
    else:
        return y
def add(x,y):
    return x+y
    
def typecasting(l):
    l[3]=int(float(l[3]))
    return l
def get_key(kv):
    return kv[0]
def output_format(kv):
     return "%s\t%s" % (kv[0], kv[1])

text = sc.textFile(inputs)
words = text.flatMap(words_once).map(typecasting).filter(lambda x:(x[1]=="en")and(x[2]!="Main_Page")and(x[2].find("Special:",0,9)==-1)).map(lambda x:(x[0],(x[3],x[2])))
wikipedia_popular = words.reduceByKey(max_value)
outdata = wikipedia_popular.sortBy(get_key).map(output_format)
print(outdata.take(10))
outdata.saveAsTextFile(output)