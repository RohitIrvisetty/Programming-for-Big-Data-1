from pyspark import SparkConf, SparkContext
import sys,re,string

inputs = sys.argv[1]
output = sys.argv[2]

conf = SparkConf().setAppName('wordcount_improved')
sc = SparkContext(conf=conf)
assert sys.version_info >= (3, 5)  # make sure we have Python 3.5+
assert sc.version >= '2.3'  # make sure we have Spark 2.3+

def words_once(line):
    word_sep = re.compile(r'[%s\s]+' % re.escape(string.punctuation))
    tokens=word_sep.split(line)
    tokens_mapped=map(lambda x:x.lower(),tokens)
    tokens_final=filter(lambda x:len(x)>0,tokens_mapped)
    for w in tokens_final:
        yield (w, 1)

def add(x, y):
    return x + y

def get_key(kv):
    return kv[0]

def output_format(kv):
    k, v = kv
    return '%s %i' % (k, v)

text = sc.textFile(inputs)
words = text.flatMap(words_once)
wordcount_improved = words.reduceByKey(add)
outdata = wordcount_improved.sortBy(get_key).map(output_format)
print(outdata.take(10))
outdata.saveAsTextFile(output)