import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import java.util.regex.Pattern;
import org.json.JSONObject;

public class RedditAverage extends Configured implements Tool {

	public static class Redditaverage_mapper extends Mapper<LongWritable, Text, Text, LongPairWritable>{
		private Text word=new Text();
		private LongPairWritable pair=new LongPairWritable();
		
		public void map(LongWritable key, Text value, Context context
		) throws IOException, InterruptedException {

			JSONObject record=new JSONObject(value.toString());	
			word.set((String) record.get("subreddit"));	
			pair.set(1,(Integer) record.get("score"));	
			context.write(word,pair);	
		}
	}

	public static class Redditaverage_combiner extends Reducer<Text, LongPairWritable, Text, LongPairWritable> {
		private LongPairWritable pair = new LongPairWritable();
		public void combine(Text key, Iterable<LongPairWritable> values, Context context
		) throws IOException, InterruptedException {
			long comment_count=0,totalscore=0;
			for (LongPairWritable val : values) {
				comment_count+=val.get_0();
				totalscore+=val.get_1();
			}
			pair.set(comment_count,totalscore);	
			context.write(key,pair);
		}
	}

	
	public static class Redditaverage_reducer extends Reducer<Text, LongPairWritable, Text, DoubleWritable> {
		private DoubleWritable reducer_value = new DoubleWritable();
		public void reduce(Text key, Iterable<LongPairWritable> values,Context context
		) throws IOException, InterruptedException {
			
			double comment_count=0,totalscore=0,Reddit_average;
			for (LongPairWritable val : values) {
				comment_count+=val.get_0();
				totalscore+=val.get_1();
			}
			Reddit_average=totalscore/comment_count;	
			reducer_value.set(Reddit_average);
			context.write(key, reducer_value);	
		}
	}

    public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new RedditAverage(), args);
		System.exit(res);
	}

        @Override
	    public int run(String[] args) throws Exception {
		    Configuration conf = this.getConf();
		    Job job = Job.getInstance(conf, "RedditAverage");
		    job.setJarByClass(RedditAverage.class);

		    job.setInputFormatClass(TextInputFormat.class);

		    job.setMapperClass(Redditaverage_mapper.class);
		    job.setCombinerClass(Redditaverage_combiner.class);
		    job.setReducerClass(Redditaverage_reducer.class);

		    job.setMapOutputKeyClass(Text.class);
		    job.setMapOutputValueClass(LongPairWritable.class);

		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(DoubleWritable.class);
		    job.setOutputFormatClass(TextOutputFormat.class);
        
		    TextInputFormat.addInputPath(job, new Path(args[0]));
		    TextOutputFormat.setOutputPath(job, new Path(args[1]));

		    return job.waitForCompletion(true) ? 0 : 1;
		}
}